BUILD A TERRARIUM UI - ROBLOX PLACE
===================================

What's here
  BuildATerrarium_UI.rbxlx            Double-click to open in Roblox Studio. The whole UI is already built
                                      (StarterGui), with its scripts, plus a small test world.
  BuildATerrarium_UI_StarterGui.rbxm  The same UI on its own: right-click StarterGui > Insert from File
                                      to drop it straight into your real game.
  Sheets/                             14 images. Every UI picture is packed onto these.

Setup (about 5 minutes, once). Until you do this you see text and coloured boxes, which is expected.
  1. Open BuildATerrarium_UI.rbxlx, then File > Publish to Roblox (Asset Manager needs a saved place).
  2. View > Asset Manager > Bulk Import > select the 14 PNGs in Sheets/.
  3. Right-click each one > Copy Asset ID.
  4. Open the command bar (View > Command Bar), paste this with your 14 numbers, press Enter:
       require(game.StarterGui.UI_Core.Runtime.SetSheetIds)({
           Sheet_01 = 0, Sheet_02 = 0, Sheet_03 = 0, Sheet_04 = 0, Sheet_05 = 0, Sheet_06 = 0, Sheet_07 = 0,
           Sheet_08 = 0, Sheet_09 = 0, Sheet_10 = 0, Sheet_11 = 0, Sheet_12 = 0, Sheet_13 = 0, Sheet_Studs = 0,
       })
     The pictures now appear in the edit view. (You can also paste each ID by hand into
     StarterGui > UI_Core > SheetIds.)
  5. Press Play (F5). Open View > Output: you should see "[UI] ... images linked" and "[UI] ready".
  6. Save the place again.

Try it in Play mode
  - HUD buttons open their panels; X closes. Shop / My Terrarium / Upgrades teleport to the test stands.
  - Walk up to the terrarium (Edit Tank slides in, HUD fades), the Keeper and Upgrades stands, the
    incubators (pop-ups appear when you're close) and the egg (hover it; press E on the prompt to hatch).
  - Test keys: 1 good toast, 2 error toast, 3 Wilds banner, 4 safe banner, 5 rare-hatch announcement,
    6 event starts, 7 / 8 Shillings up / down, 9 Bioactivity +10, 0 Hatch Reveal (cycles rarities),
    H Hatch Reveal with a full tank, E egg flies into the Eggs button.
  - Settings: toggles switch, sliders drag. Daily Rewards: Claim works. Store categories switch.
    Release: checkboxes tick, Hold to Release fills while held.

Moving it into your game
  Copy every UI_ ScreenGui and UI_Core from StarterGui into your game's StarterGui (or insert the .rbxm),
  and TerrariumNavigation into ServerScriptService. Delete UIDemo and WorldDemo (test only).
  Hook-ups for your systems: set the player attributes "Shillings" and "Bioactivity" from the server;
  give ProximityPrompts an attribute OpensPanel = "EditTank_Layers" / "KeepersShop" / "Upgrades" / ...;
  HatchReveal.show{...}, Notifications.toast/banner/announce/eventStarted, IncubatorPopup, EggFX are in
  UI_Core.Runtime (each module explains itself at the top).

Notes
  - Text is real TextLabels in Comic Neue Angular Bold. If your Studio doesn't have that font, select the
    labels and change FontFace (Fredoka One is closest).
  - Creature / egg spots are empty frames named CreatureSlot / EggSlot for your 3D models.
  - Sound IDs go in UI_Core.Runtime.UIConfig (missing ones are skipped).
  - Images are packed at design resolution to keep the upload count low. The full-resolution PNGs are in
    the earlier Build_a_Terrarium_UI_Studio.zip if you ever want to swap any in.
